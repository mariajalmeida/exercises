These are the two versions of animal base

animals_basic is the original, using just the JSON objects

animals_objects is the new and improved, but incomplete.
Your job is to add code to animals_objects, so it works.
The HTML is complete. You only need to work with the JS.